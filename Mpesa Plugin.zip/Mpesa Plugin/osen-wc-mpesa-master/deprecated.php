<?php
// This file containtains functionality that is no longer used and will be removed in the future.