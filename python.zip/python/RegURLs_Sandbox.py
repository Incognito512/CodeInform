import requests
import json

# Function to get access token (assuming this is defined elsewhere)
def get_access_token():
    consumer_key = 'WBO40j0jMAthf4Go9hgjAPLr8BtSlnSd'  # Fill with your app Consumer Key
    consumer_secret = 'hGF79OCNOSeIPuaQ'  # Fill with your app Secret
    url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
    response = requests.get(url, auth=(consumer_key, consumer_secret))
    if response.status_code == 200:
        return response.json().get('access_token')
    else:
        raise Exception('Failed to get access token')

access_token = get_access_token()  # Get the access token
short_code = '174379'  # Provide the short code obtained from your test credentials

# URLs for confirmation and validation
confirmation_url = 'https://mydomain.co.uk/api/confirmation_url.py'
validation_url = 'https://mydomain.co.uk/api/validation_url.py'

# URL for registering C2B URL
url = 'https://sandbox.safaricom.co.ke/mpesa/c2b/v2/registerurl'

# Headers
headers = {
    'Content-Type': 'application/json',
    'Authorization': f'Bearer {access_token}'
}

# Request data
data = {
    'ShortCode': short_code,
    'ResponseType': 'Completed',
    'ConfirmationURL': confirmation_url,
    'ValidationURL': validation_url
}

# Making the request
response = requests.post(url, headers=headers, json=data)

# Output the response
print(response.text)
