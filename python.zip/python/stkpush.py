import base64
import requests
from datetime import datetime

def mpesa(phone, amount, ordernum):
    # Callback URL
    CALLBACK_URL = 'https://mydomain.co.ke/api/callback_url.py?orderid='

    # Access token
    consumerKey = ''  # Fill with your app Consumer Key
    consumerSecret = ''  # Fill with your app Secret

    # Provide the following details, this part is found on your test credentials on the developer account
    BusinessShortCode = ''  # business short code
    Passkey = ''  # live passkey
    phone = phone.replace('+', '').replace('0', '254', 1)
    PartyA = phone  # This is your phone number
    PartyB = ''
    TransactionDesc = 'Pay Order'  # Insert your own description
    # Get the timestamp, format YYYYmmddhms -> 20181004151020
    Timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    # Get the base64 encoded string -> password. The passkey is the M-PESA Public Key
    Password = base64.b64encode(f"{BusinessShortCode}{Passkey}{Timestamp}".encode()).decode('utf-8')

    # M-PESA endpoint URLs
    access_token_url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
    initiate_url = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'

    # Get the access token
    response = requests.get(access_token_url, auth=(consumerKey, consumerSecret))
    access_token = response.json().get('access_token')

    # Header for stk push
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {access_token}'
    }

    # Initiating the transaction
    curl_post_data = {
        'BusinessShortCode': BusinessShortCode,
        'Password': Password,
        'Timestamp': Timestamp,
        'TransactionType': 'CustomerPayBillOnline',  # CustomerBuyGoodsOnline
        'Amount': amount,
        'PartyA': PartyA,
        'PartyB': PartyB,
        'PhoneNumber': PartyA,
        'CallBackURL': f'{CALLBACK_URL}{ordernum}',
        'AccountReference': ordernum,
        'TransactionDesc': TransactionDesc
    }

    response = requests.post(initiate_url, json=curl_post_data, headers=headers)
    return response.json()

phone = '0711930472'
amount = 1
invoice = datetime.now().strftime('%Y%m%d%H%M%S')

# Call mpesa stkpush function
response = mpesa(phone, amount, invoice)
print(response)
