import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import connections, connection

@csrf_exempt
def mpesa_confirmation(request):
    if request.method == 'POST':
        # Get the M-PESA response data from the request body
        mpesa_response = request.body
        content = json.loads(mpesa_response)
        
        # Extracting all fields from the JSON data
        TransactionType = content.get('TransactionType')
        TransID = content.get('TransID')
        TransTime = content.get('TransTime')
        TransAmount = content.get('TransAmount')
        BusinessShortCode = content.get('BusinessShortCode')
        BillRefNumber = content.get('BillRefNumber')
        InvoiceNumber = content.get('InvoiceNumber', '')
        OrgAccountBalance = content.get('OrgAccountBalance', '')
        ThirdPartyTransID = content.get('ThirdPartyTransID', '')
        MSISDN = content.get('MSISDN')
        FirstName = content.get('FirstName')
        MiddleName = content.get('MiddleName', '')
        LastName = content.get('LastName')
        
        # Database connection details
        db_settings = {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': 'DBNAME',
            'USER': 'DBUSER',
            'PASSWORD': 'DBPASSWORD',
            'HOST': 'localhost',
            'PORT': '3306',
        }

        # Ensure the required fields are not empty
        if TransID:
            # Insert transaction into Mpesa_Transactions table
            with connections.databases.update({'default': db_settings}):
                with connection.cursor() as cursor:
                    cursor.execute(
                        """
                        INSERT INTO Mpesa_Transactions 
                        (
                            transaction_type, trans_id, trans_time, trans_amount, business_short_code, 
                            bill_ref_number, invoice_number, org_account_balance, third_party_trans_id, 
                            msisdn, first_name, middle_name, last_name
                        ) 
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        [
                            TransactionType, TransID, TransTime, TransAmount, BusinessShortCode,
                            BillRefNumber, InvoiceNumber, OrgAccountBalance, ThirdPartyTransID,
                            MSISDN, FirstName, MiddleName, LastName
                        ]
                    )

        # Response to send back to M-PESA
        response = {
            "ResultCode": 0,
            "ResultDesc": "Confirmation Received Successfully"
        }

        return JsonResponse(response)
